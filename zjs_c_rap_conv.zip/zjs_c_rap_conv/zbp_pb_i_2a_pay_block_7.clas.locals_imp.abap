CLASS lhc_ZPB_I_2A_PAY_BLOCK_7 DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR PayBlock RESULT result.

    METHODS pbf FOR MODIFY
      IMPORTING keys FOR ACTION PayBlock~pbf RESULT result.

    METHODS process FOR MODIFY
      IMPORTING keys FOR ACTION PayBlock~process RESULT result.

    METHODS unblock FOR MODIFY
      IMPORTING keys FOR ACTION PayBlock~unblock RESULT result.

ENDCLASS.

CLASS lhc_ZPB_I_2A_PAY_BLOCK_7 IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD pbf.
  ENDMETHOD.

  METHOD process.
    DATA lo_processor TYPE REF TO zcl_pb_processor_final.

    READ ENTITIES OF zpb_i_2a_pay_block_7 IN LOCAL MODE
      ENTITY PayBlock ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_data)
                                                              FAILED DATA(lt_failed)
                                                              REPORTED DATA(lt_reported).

    DATA(wa_data1) = lt_data[ 1 ] .

    lo_processor = NEW zcl_pb_processor_final( iv_p_pbf    = wa_data1-p_pbf
                                               iv_p_jv     = wa_data1-p_jv
                                               iv_p_dbf    = wa_data1-p_dbf
                                               iv_p_daf    = wa_data1-p_daf
                                               iv_p_dbf_cl = wa_data1-p_dbf_cl
                                               iv_p_dbf_op = wa_data1-p_dbf_op
                                               iv_p_daf_cl = wa_data1-p_daf_cl
                                               iv_p_daf_op = wa_data1-p_daf_op  ).



    LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<data>).
      DATA(ls_data) = CORRESPONDING zpb_i_2a_pay_block_7( <data> ).

      DATA(rv_processed) = lo_processor->process( CHANGING cs_data = ls_data ).

      APPEND VALUE #(
        %tky = <data>-%tky
        %param = CORRESPONDING #( ls_data )
      ) TO result.

    ENDLOOP.

  ENDMETHOD.

  METHOD unblock.

    DATA lo_processor TYPE REF TO zcl_pb_processor_final.

    READ ENTITIES OF zpb_i_2a_pay_block_7 IN LOCAL MODE
      ENTITY PayBlock ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_data)
                                                              FAILED DATA(lt_failed)
                                                              REPORTED DATA(lt_reported).

    DATA(wa_data1) = lt_data[ 1 ] .

    lo_processor = NEW zcl_pb_processor_final( iv_p_pbf    = wa_data1-p_pbf
                                               iv_p_jv     = wa_data1-p_jv
                                               iv_p_dbf    = wa_data1-p_dbf
                                               iv_p_daf    = wa_data1-p_daf
                                               iv_p_dbf_cl = wa_data1-p_dbf_cl
                                               iv_p_dbf_op = wa_data1-p_dbf_op
                                               iv_p_daf_cl = wa_data1-p_daf_cl
                                               iv_p_daf_op = wa_data1-p_daf_op  ).



    LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<data>).
      DATA(ls_data) = CORRESPONDING zpb_i_2a_pay_block_7( <data> ).

      DATA(rv_processed) = lo_processor->unblock2( CHANGING cs_data = ls_data ).

      APPEND VALUE #(
        %tky = <data>-%tky
        %param = CORRESPONDING #( ls_data )
      ) TO result.

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.
